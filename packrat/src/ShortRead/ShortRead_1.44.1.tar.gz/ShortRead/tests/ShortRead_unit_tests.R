BiocGenerics:::testPackage("ShortRead")
