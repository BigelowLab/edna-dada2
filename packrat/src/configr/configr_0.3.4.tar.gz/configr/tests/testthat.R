library(testthat)
library(configr)
library(stringr)


test_check("configr")
